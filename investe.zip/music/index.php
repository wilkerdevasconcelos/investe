<?php

// Usuário e ApiKey do Youtube
$username = 'videosimprovaveis';

// Crie uma API KEY no https://code.google.com/apis/console, não se esqueça de habilitar o Youtube Data API
$apiKey = 'SUA API KEY AQUI';

$channelUrl = "https://www.googleapis.com/youtube/v3/channels?forUsername={$username}&part=contentDetails&key={$apiKey}";
$videosUrl = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=20&key={$apiKey}";

function request($url) {
  $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
  $body = curl_exec($curl);
  curl_close($curl);

  return json_decode($body);
}

$channel = request($channelUrl)->items[0]->contentDetails;
$playlistId = $channel->relatedPlaylists->uploads;

$videos = request("{$videosUrl}&playlistId={$playlistId}")->items;